import os
import openai
from flask import Flask, render_template, request, redirect, url_for, flash
import time

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Configure OpenAI API (replace with your actual OpenAI API key)
openai.api_key = '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'

# Global variables to store quiz state
questions = []
user_answers = []

def generate_questions(topic, num_questions):
    global questions
    questions = []
    for i in range(num_questions):
        question = f"Generate a multiple-choice question on {topic}."
        success = False
        retries = 0
        while not success and retries < 5:
            try:
                response = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": "You are a helpful assistant."},
                        {"role": "user", "content": question}
                    ],
                    max_tokens=100
                )
                # Assuming the response returns a list of choices
                choices = ['Choice A', 'Choice B', 'Choice C', 'Choice D']  # Replace with actual choices
                questions.append({
                    'question': response.choices[0].message['content'].strip(),
                    'options': choices  # Store options as a list
                })
                success = True
            except openai.error.RateLimitError:
                retries += 1
                time.sleep(2 ** retries)  # Exponential backoff

@app.route('/', methods=['GET', 'POST'])
def quiz():
    global questions, user_answers
    
    if request.method == 'POST':
        if 'topic' in request.form and 'num_questions' in request.form:
            topic = request.form['topic']
            num_questions = int(request.form['num_questions'])
            generate_questions(topic, num_questions)
            user_answers = [''] * num_questions  # Initialize user answers list
            
            # Pass enumerate explicitly to template context
            return render_template('quiz.html', questions=questions, enumerate=enumerate)
    
    # If it's a GET request or no valid form data, render the initial form
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit_quiz():
    global questions, user_answers
    
    if request.method == 'POST':
        # Process user answers
        for i in range(len(questions)):
            answer_key = f'answer_{i}'
            if answer_key in request.form:
                user_answers[i] = request.form[answer_key]
        
        return redirect(url_for('show_results'))  # Redirect to results page after submitting

@app.route('/results', methods=['GET'])
def show_results():
    global questions, user_answers
    
    # Mocking correct answers (replace with actual correct answers logic)
    correct_answers = ['Choice B', 'Choice A', 'Choice C', 'Choice D']
    
    # Prepare data for results display
    results = []
    for i in range(len(questions)):
        if i < len(questions) and i < len(user_answers):
            results.append({
                'question': questions[i]['question'],
                'options': questions[i]['options'],
                'user_answer': user_answers[i],
                'correct_answer': correct_answers[i]  # Include correct answer
            })
    
    # Clear quiz state after showing results
    questions.clear()
    user_answers.clear()
    
    # Calculate accuracy (dummy calculation as we are not showing correct answers)
    accuracy = 0.0
    
    # Flash the accuracy score for display on the results page
    flash(f'Accuracy Score: {accuracy*100}%')
    
    return render_template('results.html', accuracy=accuracy, results=results)

if __name__ == '__main__':
    app.run(debug=True)
